# virtualizacion
La documentacion para la platica de virtualizacion
un cambio no autorizado de JCL
